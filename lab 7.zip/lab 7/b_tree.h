#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

struct Date {
    int day, month, year;
};

struct PawnItem {
    int index;
    string customerName;
    string customerSurname;
    string itemName;
    double itemValue;
    Date contractDate;
    Date maturityDate;
};

class BTreeNode {
public:
    PawnItem* items;
    int t;
    BTreeNode** C;
    int n;
    bool leaf;

    BTreeNode(int _t, bool _leaf);
    void traverse();
    BTreeNode* search(int k);
    void insertNonFull(PawnItem k);
    void splitChild(int i, BTreeNode* y);
    void remove(int k);
    void removeFromLeaf(int idx);
    void removeFromNonLeaf(int idx);
    int findKey(int k);
    PawnItem getPred(int idx);
    PawnItem getSucc(int idx);
    void fill(int idx);
    void borrowFromPrev(int idx);
    void borrowFromNext(int idx);
    void merge(int idx);
    void saveToFile(ofstream& file, bool isBinary);
    void loadFromFile(ifstream& file, bool isBinary, vector<PawnItem>& items);
    friend class BTree;
};

class BTree {
public:
    BTreeNode* root;
    int t;

    BTree(int _t) {
        root = nullptr;
        t = _t;
    }

    void traverse() {
        if (root != nullptr) root->traverse();
    }

    BTreeNode* search(int k) {
        return (root == nullptr) ? nullptr : root->search(k);
    }

    void insert(PawnItem k);
    void remove(int k);
    void saveToFile(const string& filename, bool isBinary);
    void loadFromFile(const string& filename, bool isBinary);
};

BTreeNode::BTreeNode(int t1, bool leaf1) {
    t = t1;
    leaf = leaf1;

    items = new PawnItem[2 * t - 1];
    C = new BTreeNode * [2 * t];

    n = 0;
}

int BTreeNode::findKey(int k) {
    int idx = 0;
    while (idx < n && items[idx].index < k)
        ++idx;
    return idx;
}

void BTreeNode::remove(int k) {
    int idx = findKey(k);

    if (idx < n && items[idx].index == k) {
        if (leaf)
            removeFromLeaf(idx);
        else
            removeFromNonLeaf(idx);
    } else {
        if (leaf) {
            cout << "The key " << k << " is not present in the tree.\n";
            return;
        }

        bool flag = ((idx == n) ? true : false);

        if (C[idx]->n < t)
            fill(idx);

        if (flag && idx > n)
            C[idx - 1]->remove(k);
        else
            C[idx]->remove(k);
    }
    return;
}

void BTreeNode::removeFromLeaf(int idx) {
    for (int i = idx + 1; i < n; ++i)
        items[i - 1] = items[i];

    n--;

    return;
}

void BTreeNode::removeFromNonLeaf(int idx) {
    PawnItem k = items[idx];

    if (C[idx]->n >= t) {
        PawnItem pred = getPred(idx);
        items[idx] = pred;
        C[idx]->remove(pred.index);
    } else if (C[idx + 1]->n >= t) {
        PawnItem succ = getSucc(idx);
        items[idx] = succ;
        C[idx + 1]->remove(succ.index);
    } else {
        merge(idx);
        C[idx]->remove(k.index);
    }
    return;
}

PawnItem BTreeNode::getPred(int idx) {
    BTreeNode* cur = C[idx];
    while (!cur->leaf)
        cur = cur->C[cur->n];

    return cur->items[cur->n - 1];
}

PawnItem BTreeNode::getSucc(int idx) {
    BTreeNode* cur = C[idx + 1];
    while (!cur->leaf)
        cur = cur->C[0];

    return cur->items[0];
}

void BTreeNode::fill(int idx) {
    if (idx != 0 && C[idx - 1]->n >= t)
        borrowFromPrev(idx);
    else if (idx != n && C[idx + 1]->n >= t)
        borrowFromNext(idx);
    else {
        if (idx != n)
            merge(idx);
        else
            merge(idx - 1);
    }
    return;
}

void BTreeNode::borrowFromPrev(int idx) {
    BTreeNode* child = C[idx];
    BTreeNode* sibling = C[idx - 1];

    for (int i = child->n - 1; i >= 0; --i)
        child->items[i + 1] = child->items[i];

    if (!child->leaf) {
        for (int i = child->n; i >= 0; --i)
            child->C[i + 1] = child->C[i];
    }

    child->items[0] = items[idx - 1];

    if (!leaf)
        child->C[0] = sibling->C[sibling->n];

    items[idx - 1] = sibling->items[sibling->n - 1];

    child->n += 1;
    sibling->n -= 1;

    return;
}

void BTreeNode::borrowFromNext(int idx) {
    BTreeNode* child = C[idx];
    BTreeNode* sibling = C[idx + 1];

    child->items[(child->n)] = items[idx];

    if (!(child->leaf))
        child->C[(child->n) + 1] = sibling->C[0];

    items[idx] = sibling->items[0];

    for (int i = 1; i < sibling->n; ++i)
        sibling->items[i - 1] = sibling->items[i];

    if (!sibling->leaf) {
        for (int i = 1; i <= sibling->n; ++i)
            sibling->C[i - 1] = sibling->C[i];
    }

    child->n += 1;
    sibling->n -= 1;

    return;
}

void BTreeNode::merge(int idx) {
    BTreeNode* child = C[idx];
    BTreeNode* sibling = C[idx + 1];

    child->items[t - 1] = items[idx];

    for (int i = 0; i < sibling->n; ++i)
        child->items[i + t] = sibling->items[i];

    if (!child->leaf) {
        for (int i = 0; i <= sibling->n; ++i)
            child->C[i + t] = sibling->C[i];
    }

    for (int i = idx + 1; i < n; ++i)
        items[i - 1] = items[i];

    for (int i = idx + 2; i <= n; ++i)
        C[i - 1] = C[i];

    child->n += sibling->n + 1;
    n--;

    delete (sibling);
    return;
}

void BTree::insert(PawnItem k) {
    if (root == nullptr) {
        root = new BTreeNode(t, true);
        root->items[0] = k;
        root->n = 1;
    } else {
        if (root->n == 2 * t - 1) {
            BTreeNode* s = new BTreeNode(t, false);

            s->C[0] = root;

            s->splitChild(0, root);

            int i = 0;
            if (s->items[0].index < k.index)
                i++;
            s->C[i]->insertNonFull(k);

            root = s;
        } else
            root->insertNonFull(k);
    }
}

void BTreeNode::insertNonFull(PawnItem k) {
    int i = n - 1;

    if (leaf) {
        while (i >= 0 && items[i].index > k.index) {
            items[i + 1] = items[i];
            i--;
        }

        items[i + 1] = k;
        n = n + 1;
    } else {
        while (i >= 0 && items[i].index > k.index)
            i--;

        if (C[i + 1]->n == 2 * t - 1) {
            splitChild(i + 1, C[i + 1]);

            if (items[i + 1].index < k.index)
                i++;
        }
        C[i + 1]->insertNonFull(k);
    }
}

void BTreeNode::splitChild(int i, BTreeNode* y) {
    BTreeNode* z = new BTreeNode(y->t, y->leaf);
    z->n = t - 1;

    for (int j = 0; j < t - 1; j++)
        z->items[j] = y->items[j + t];

    if (!y->leaf) {
        for (int j = 0; j < t; j++)
            z->C[j] = y->C[j + t];
    }

    y->n = t - 1;

    for (int j = n; j >= i + 1; j--)
        C[j + 1] = C[j];

    C[i + 1] = z;

    for (int j = n - 1; j >= i; j--)
        items[j + 1] = items[j];

    items[i] = y->items[t - 1];

    n = n + 1;
}

void BTree::remove(int k) {
    if (!root) {
        cout << "The tree is empty\n";
        return;
    }

    root->remove(k);

    if (root->n == 0) {
        BTreeNode* tmp = root;
        if (root->leaf)
            root = nullptr;
        else
            root = root->C[0];

        delete tmp;
    }
    return;
}

void BTreeNode::traverse() {
    int i;
    for (i = 0; i < n; i++) {
        if (!leaf) C[i]->traverse();
        cout << "Index: " << items[i].index << ", "
             << "Name: " << items[i].customerName << ", "
             << "Surname: " << items[i].customerSurname << ", "
             << "Item Name: " << items[i].itemName << ", "
             << "Item Value: " << items[i].itemValue << ", "
             << "Contract Date: " << items[i].contractDate.day << "/" << items[i].contractDate.month << "/" << items[i].contractDate.year << ", "
             << "Maturity Date: " << items[i].maturityDate.day << "/" << items[i].maturityDate.month << "/" << items[i].maturityDate.year << endl;
    }

    if (!leaf) C[i]->traverse();
}

BTreeNode* BTreeNode::search(int k) {
    int i = 0;
    while (i < n && k > items[i].index)
        i++;

    if (items[i].index == k)
        return this;

    if (leaf)
        return nullptr;

    return C[i]->search(k);
}

void BTreeNode::saveToFile(ofstream& file, bool isBinary) {
    for (int i = 0; i < n; i++) {
        if (isBinary) {
            file.write(reinterpret_cast<char*>(&items[i]), sizeof(PawnItem));
        } else {
            file << items[i].index << " " << items[i].customerName << " " << items[i].customerSurname << " "
                 << items[i].itemName << " " << items[i].itemValue << " "
                 << items[i].contractDate.day << "/" << items[i].contractDate.month << "/" << items[i].contractDate.year << " "
                 << items[i].maturityDate.day << "/" << items[i].maturityDate.month << "/" << items[i].maturityDate.year << "\n";
        }
    }

    if (!leaf) {
        for (int i = 0; i <= n; i++) {
            C[i]->saveToFile(file, isBinary);
        }
    }
}

void BTree::saveToFile(const string& filename, bool isBinary) {
    ofstream file;
    if (isBinary) {
        file.open(filename, ios::binary);
    } else {
        file.open(filename);
    }

    if (!file) {
        cout << "Error opening file." << endl;
        return;
    }

    if (root) {
        root->saveToFile(file, isBinary);
    }

    file.close();
    cout << "B-tree saved to file successfully." << endl;
}

void BTreeNode::loadFromFile(ifstream& file, bool isBinary, vector<PawnItem>& items) {
    PawnItem item;
    while (isBinary ? file.read(reinterpret_cast<char*>(&item), sizeof(PawnItem)) : file >> item.index) {
        if (!isBinary) {
            file >> item.customerName >> item.customerSurname >> item.itemName >> item.itemValue;
            char slash;
            file >> item.contractDate.day >> slash >> item.contractDate.month >> slash >> item.contractDate.year;
            file >> item.maturityDate.day >> slash >> item.maturityDate.month >> slash >> item.maturityDate.year;
        }
        items.push_back(item);
    }
}

void BTree::loadFromFile(const string& filename, bool isBinary) {
    ifstream file;
    if (isBinary) {
        file.open(filename, ios::binary);
    } else {
        file.open(filename);
    }

    if (!file) {
        cout << "Error opening file." << endl;
        return;
    }

    vector<PawnItem> items;
    root->loadFromFile(file, isBinary, items);

    for (size_t i = 0; i < items.size(); ++i) {
        insert(items[i]);
    }

    file.close();
    cout << "B-tree loaded from file successfully." << endl;
}


vector<string> savedFiles;

void deleteAllSavedFiles() {
    for (size_t i = 0; i < savedFiles.size(); ++i) {
        const string& filename = savedFiles[i];
        if (remove(filename.c_str()) == 0) {
            cout << "Deleted file: " << filename << endl;
        } else {
            cout << "Unable to delete file: " << filename << endl;
        }
    }
    savedFiles.clear();
}

void displayMenu() {
    cout << "Main Menu:\n";
    cout << "1. Display all items\n";
    cout << "2. Insert an item\n";
    cout << "3. Delete an item\n";
    cout << "4. Search for an item\n";
    cout << "5. Save to file\n";
    cout << "6. Load from file\n";
    cout << "7. Delete all saved files\n";
    cout << "0. Exit\n";
}

void displayInsertMenu() {
    cout << "Insert Menu:\n";
    cout << "1. Insert at the beginning\n";
    cout << "2. Insert at the end\n";
    cout << "3. Insert at a specific index\n";
}

void displayDeleteMenu() {
    cout << "Delete Menu:\n";
    cout << "1. Delete by index\n";
    cout << "2. Delete by value\n";
}

void displaySearchMenu() {
    cout << "Search Menu:\n";
    cout << "1. Search by index\n";
    cout << "2. Search by value\n";
}

void displaySaveMenu() {
    cout << "Save Menu:\n";
    cout << "1. Save as .txt\n";
    cout << "2. Save as .bin\n";
}

void displayLoadMenu() {
    cout << "Load Menu:\n";
    cout << "1. Load from .txt\n";
    cout << "2. Load from .bin\n";
}
void searchByValue(BTreeNode* node, const string& searchName, const string& searchSurname, const string& searchItemName, vector<PawnItem>& foundItems, bool& found) {
    int i = 0;
    while (i < node->n && searchSurname > node->items[i].customerSurname) {
        i++;
    }

    if (node->leaf) {
        while (i < node->n && searchSurname == node->items[i].customerSurname) {
            if (searchName == node->items[i].customerName && searchItemName == node->items[i].itemName) {
                foundItems.push_back(node->items[i]);
                found = true;
            }
            i++;
        }
    } else {
        while (i < node->n && searchSurname == node->items[i].customerSurname) {
            if (searchName == node->items[i].customerName && searchItemName == node->items[i].itemName) {
                foundItems.push_back(node->items[i]);
                found = true;
            }
            i++;
        }
        searchByValue(node->C[i], searchName, searchSurname, searchItemName, foundItems, found);
    }
}

void BTreeProgram() {
    BTree tree(3);
    int choice;
    PawnItem item;
    string fileName;

    do {
        displayMenu();
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
        case 1:
            tree.traverse();
            break;
        case 2:
            displayInsertMenu();
            int insertChoice;
            cin >> insertChoice;
            switch (insertChoice) {
            case 1:
                cout << "Enter customer name: ";
                cin >> item.customerName;
                cout << "Enter customer surname: ";
                cin >> item.customerSurname;
                cout << "Enter item name: ";
                cin.ignore();
                getline(cin, item.itemName);
                cout << "Enter item value: ";
                cin >> item.itemValue;
                cout << "Enter contract date (day month year): ";
                cin >> item.contractDate.day >> item.contractDate.month >> item.contractDate.year;
                cout << "Enter maturity date (day month year): ";
                cin >> item.maturityDate.day >> item.maturityDate.month >> item.maturityDate.year;
                item.index = 1; // Adjust index as needed
                tree.insert(item);
                break;
            case 2:
                cout << "Enter customer name: ";
                cin >> item.customerName;
                cout << "Enter customer surname: ";
                cin >> item.customerSurname;
                cout << "Enter item name: ";
                cin.ignore();
                getline(cin, item.itemName);
                cout << "Enter item value: ";
                cin >> item.itemValue;
                cout << "Enter contract date (day month year): ";
                cin >> item.contractDate.day >> item.contractDate.month >> item.contractDate.year;
                cout << "Enter maturity date (day month year): ";
                cin >> item.maturityDate.day >> item.maturityDate.month >> item.maturityDate.year;
                item.index = 2; // Adjust index as needed
                tree.insert(item);
                break;
            case 3:
                cout << "Enter index to insert: ";
                cin >> item.index;
                cout << "Enter customer name: ";
                cin >> item.customerName;
                cout << "Enter customer surname: ";
                cin >> item.customerSurname;
                cout << "Enter item name: ";
                cin.ignore();
                getline(cin, item.itemName);
                cout << "Enter item value: ";
                cin >> item.itemValue;
                cout << "Enter contract date (day month year): ";
                cin >> item.contractDate.day >> item.contractDate.month >> item.contractDate.year;
                cout << "Enter maturity date (day month year): ";
                cin >> item.maturityDate.day >> item.maturityDate.month >> item.maturityDate.year;
                tree.insert(item);
                break;
            default:
                cout << "Invalid choice.\n";
            }
            break;
        case 3:
            displayDeleteMenu();
            int deleteChoice;
            cin >> deleteChoice;
            switch (deleteChoice) {
            case 1: {
                int delIndex;
                cout << "Enter index of the item to delete: ";
                cin >> delIndex;
                tree.remove(delIndex);
                break;
            }
            case 2: {
                string delName, delSurname, delItemName;
                cout << "Enter customer name: ";
                cin >> delName;
                cout << "Enter customer surname: ";
                cin >> delSurname;
                cout << "Enter item name: ";
                cin.ignore();
                getline(cin, delItemName);
                // Implement delete by value if needed
                break;
            }
            default:
                cout << "Invalid choice.\n";
            }
            break;
        case 4:
    displaySearchMenu();
    int searchChoice;
    cin >> searchChoice;
    switch (searchChoice) {
    case 1: {
        int searchIndex;
        cout << "Enter the index to search: ";
        cin >> searchIndex;
        BTreeNode* foundNode = tree.search(searchIndex);
        if (foundNode != nullptr) {
            cout << "Item found:\n";
            cout << "Index: " << foundNode->items[0].index << ", "
                 << "Name: " << foundNode->items[0].customerName << ", "
                 << "Surname: " << foundNode->items[0].customerSurname << ", "
                 << "Item Name: " << foundNode->items[0].itemName << ", "
                 << "Item Value: " << foundNode->items[0].itemValue << ", "
                 << "Contract Date: " << foundNode->items[0].contractDate.day << "/" << foundNode->items[0].contractDate.month << "/" << foundNode->items[0].contractDate.year << ", "
                 << "Maturity Date: " << foundNode->items[0].maturityDate.day << "/" << foundNode->items[0].maturityDate.month << "/" << foundNode->items[0].maturityDate.year << endl;
        } else {
            cout << "Item not found.\n";
        }
        break;
    }
    case 2: {
    string searchName, searchSurname, searchItemName;
    cout << "Enter customer name: ";
    cin >> searchName;
    cout << "Enter customer surname: ";
    cin >> searchSurname;
    cout << "Enter item name: ";
    cin.ignore();
    getline(cin, searchItemName);

    bool found = false;
    vector<PawnItem> foundItems;
    searchByValue(tree.root, searchName, searchSurname, searchItemName, foundItems, found);

    if (found) {
        cout << "Items found:\n";
        for (size_t i = 0; i < foundItems.size(); ++i) {
            const PawnItem& item = foundItems[i];
            cout << "Index: " << item.index << ", "
                 << "Name: " << item.customerName << ", "
                 << "Surname: " << item.customerSurname << ", "
                 << "Item Name: " << item.itemName << ", "
                 << "Item Value: " << item.itemValue << ", "
                 << "Contract Date: " << item.contractDate.day << "/" << item.contractDate.month << "/" << item.contractDate.year << ", "
                 << "Maturity Date: " << item.maturityDate.day << "/" << item.maturityDate.month << "/" << item.maturityDate.year << endl;
        }
    } else {
        cout << "No items found.\n";
    }
    break;
}

    default:
        cout << "Invalid choice.\n";
    }
    break;

        case 5:
            displaySaveMenu();
            int saveOption;
            cout << "Enter save option: ";
            cin >> saveOption;
            cin.ignore(); // Clear the input buffer
            cout << "Enter filename: ";
            cin >> fileName;
            if (saveOption == 1) {
                fileName += ".txt";
                tree.saveToFile(fileName, false); // Save as text file
            } else if (saveOption == 2) {
                fileName += ".bin";
                tree.saveToFile(fileName, true); // Save as binary file
            } else {
                cout << "Invalid save option." << endl;
            }
            savedFiles.push_back(fileName);
            break;
        case 6:
            displayLoadMenu();
            int loadOption;
            cout << "Enter load option: ";
            cin >> loadOption;
            cin.ignore(); // Clear the input buffer
            cout << "Enter filename: ";
            cin >> fileName;
            if (loadOption == 1) {
                fileName += ".txt";
                tree.loadFromFile(fileName, false);
            } else if (loadOption == 2) {
                fileName += ".bin";
                tree.loadFromFile(fileName, true);
            } else {
                cout << "Invalid load option." << endl;
            }
            break;
        case 7:
            deleteAllSavedFiles();
            break;
        case 0:
            break;
        default:
            cout << "Invalid choice.\n";
        }
    } while (choice != 0);

}

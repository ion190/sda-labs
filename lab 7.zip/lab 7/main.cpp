#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "b_tree.h"
#include "avl_tree.h"

int main() {
    int choice;
    
    printf("Choose the version of program to run:\n");
    printf("1. AVL Tree Program\n");
    printf("2. B Tree Program\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    switch(choice) {
        case 1:
            AVLTreeProgram();
            break;
        case 2:
            BTreeProgram();
            break;
        default:
            printf("Invalid choice.\n");
    }

    return 0;
}

#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
#include <string>

using namespace std;
vector<string> savedFilesAVL;
struct DateAVL {
    int day, month, year;
};

struct PItem {
    int index;
    char customerName[50];
    char customerSurname[50];
    char itemName[100];
    float itemValue;
    DateAVL contractDate;
    DateAVL maturityDate;
};

struct Node {
    PItem data;
    Node *left, *right;
    int height;
};

typedef Node* AVLTree;

int height(Node *N) {
    if (N == NULL)
        return 0;
    return N->height;
}

Node* createNode(PItem data) {
    Node* node = new Node();
    node->data = data;
    node->left = node->right = NULL;
    node->height = 1;
    return node;
}

int max(int a, int b) {
    return (a > b) ? a : b;
}

Node *rightRotate(Node *y) {
    Node *x = y->left;
    Node *T2 = x->right;
    x->right = y;
    y->left = T2;
    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;
    return x;
}

Node *leftRotate(Node *x) {
    Node *y = x->right;
    Node *T2 = y->left;
    y->left = x;
    x->right = T2;
    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;
    return y;
}

int getBalance(Node *N) {
    if (N == NULL)
        return 0;
    return height(N->left) - height(N->right);
}

Node* insertNode(Node* node, PItem data) {
    if (node == NULL)
        return(createNode(data));
    if (data.index < node->data.index)
        node->left = insertNode(node->left, data);
    else if (data.index > node->data.index)
        node->right = insertNode(node->right, data);
    else
        return node;
    node->height = 1 + max(height(node->left), height(node->right));
    int balance = getBalance(node);
    if (balance > 1 && data.index < node->left->data.index)
        return rightRotate(node);
    if (balance < -1 && data.index > node->right->data.index)
        return leftRotate(node);
    if (balance > 1 && data.index > node->left->data.index) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }
    if (balance < -1 && data.index < node->right->data.index) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }
    return node;
}

Node* minValueNode(Node* node) {
    Node* current = node;
    while (current->left != NULL)
        current = current->left;
    return current;
}

Node* deleteNode(Node* root, int key) {
    if (root == NULL)
        return root;
    if (key < root->data.index)
        root->left = deleteNode(root->left, key);
    else if (key > root->data.index)
        root->right = deleteNode(root->right, key);
    else {
        if ((root->left == NULL) || (root->right == NULL)) {
            Node *temp = root->left ? root->left : root->right;
            if (temp == NULL) {
                temp = root;
                root = NULL;
            } else
                *root = *temp;
            delete temp;
        } else {
            Node* temp = minValueNode(root->right);
            root->data = temp->data;
            root->right = deleteNode(root->right, temp->data.index);
        }
    }
    if (root == NULL)
        return root;
    root->height = 1 + max(height(root->left), height(root->right));
    int balance = getBalance(root);
    if (balance > 1 && getBalance(root->left) >= 0)
        return rightRotate(root);
    if (balance > 1 && getBalance(root->left) < 0) {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }
    if (balance < -1 && getBalance(root->right) <= 0)
        return leftRotate(root);
    if (balance < -1 && getBalance(root->right) > 0) {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
    return root;
}

Node* searchByIndex(Node* root, int index) {
    if (root == NULL || root->data.index == index)
        return root;
    if (root->data.index < index)
        return searchByIndex(root->right, index);
    return searchByIndex(root->left, index);
}

void searchByValue(Node* root, const char* name, const char* surname, const char* itemName) {
    if (root != NULL) {
        if (strcmp(root->data.customerName, name) == 0 &&
            strcmp(root->data.customerSurname, surname) == 0 &&
            strcmp(root->data.itemName, itemName) == 0) {
            cout << root->data.index << " " << root->data.customerName << " " << root->data.customerSurname << " "
                 << root->data.itemName << " " << root->data.itemValue << " "
                 << root->data.contractDate.day << "/" << root->data.contractDate.month << "/" << root->data.contractDate.year << " "
                 << root->data.maturityDate.day << "/" << root->data.maturityDate.month << "/" << root->data.maturityDate.year << endl;
        }
        searchByValue(root->left, name, surname, itemName);
        searchByValue(root->right, name, surname, itemName);
    }
}

void incrementIndexes(Node* root) {
    if (root != NULL) {
        root->data.index++;
        incrementIndexes(root->left);
        incrementIndexes(root->right);
    }
}

void incrementIndexesSpecific(Node* root, int& currentIndex) {
    if (root != NULL) {
        if (currentIndex <= root->data.index)
            root->data.index++;
        incrementIndexesSpecific(root->left, currentIndex);
        incrementIndexesSpecific(root->right, currentIndex);
    }
}

void decrementIndexes(Node* root, int startIndex) {
    if (root != NULL) {
        if (root->data.index > startIndex) {
            root->data.index--;
        }
        decrementIndexes(root->left, startIndex);
        decrementIndexes(root->right, startIndex);
    }
}

void preOrder(Node *root) {
    if (root != NULL) {
        cout << root->data.index << " " << root->data.customerName << " " << root->data.customerSurname << " "
             << root->data.itemName << " " << root->data.itemValue << " "
             << root->data.contractDate.day << "/" << root->data.contractDate.month << "/" << root->data.contractDate.year << " "
             << root->data.maturityDate.day << "/" << root->data.maturityDate.month << "/" << root->data.maturityDate.year << endl;
        preOrder(root->left);
        preOrder(root->right);
    }
}

void saveToFile(Node* root, ofstream& file, bool isBinary) {
    if (root != NULL) {
        if (isBinary) {
            file.write((char*)&root->data, sizeof(PItem));
        } else {
            file << root->data.index << " " << root->data.customerName << " " << root->data.customerSurname << " "
                 << root->data.itemName << " " << root->data.itemValue << " "
                 << root->data.contractDate.day << "/" << root->data.contractDate.month << "/" << root->data.contractDate.year << " "
                 << root->data.maturityDate.day << "/" << root->data.maturityDate.month << "/" << root->data.maturityDate.year << "\n";
        }
        saveToFile(root->left, file, isBinary);
        saveToFile(root->right, file, isBinary);
    }
}

void saveToFile(string filename, bool isBinary, Node* root) {
    ofstream file;
    if (isBinary) {
        file.open(filename, ios::binary);
    } else {
        file.open(filename);
    }

    if (!file) {
        cout << "Error opening file." << endl;
        return;
    }

    saveToFile(root, file, isBinary);
    file.close();
    cout << "AVL tree saved to file successfully." << endl;
savedFilesAVL.push_back(filename);
}

Node* loadFromFile(ifstream& file) {
    AVLTree root = NULL;
    PItem item;
    while (file.read((char*)&item, sizeof(PItem))) {
        root = insertNode(root, item);
    }
    return root;
}

void displayInsertMenuAVL() {
    cout << "Insertion Menu:\n";
    cout << "1. Insert at the beginning\n";
    cout << "2. Insert at the end\n";
    cout << "3. Insert at a specific index\n";
}

void displayDeleteMenuAVL() {
    cout << "Deletion Menu:\n";
    cout << "1. Delete by index\n";
    cout << "2. Delete by value\n";
}

void displaySearchMenuAVL() {
    cout << "Search Menu:\n";
    cout << "1. Search by index\n";
    cout << "2. Search by value\n";
}

void displaySaveMenuAVL() {
    cout << "Save Menu:\n";
    cout << "1. Save as .txt file\n";
    cout << "2. Save as .bin file\n";
}


Node* deleteByValue(Node* root, const char* name, const char* surname, const char* itemName) {
    if (root == NULL)
        return root;
    if (strcmp(root->data.customerName, name) == 0 &&
        strcmp(root->data.customerSurname, surname) == 0 &&
        strcmp(root->data.itemName, itemName) == 0) {
        int deletedIndex = root->data.index;
        root = deleteNode(root, deletedIndex);
        decrementIndexes(root, deletedIndex);
    } else {
        root->left = deleteByValue(root->left, name, surname, itemName);
        root->right = deleteByValue(root->right, name, surname, itemName);
    }
    return root;
}
void displayLoadMenuAVL() {
    cout << "Load Menu:\n";
    cout << "1. Load from .txt file\n";
    cout << "2. Load from .bin file\n";
}
void deleteAllSavedFilesAVL() {
    for (size_t i = 0; i < savedFilesAVL.size(); i++) {
        const string& filename = savedFilesAVL[i];
        if (remove(filename.c_str()) == 0) {
            cout << "Deleted file: " << filename << endl;
        } else {
            cout << "Error deleting file: " << filename << endl;
        }
    }
    savedFilesAVL.clear(); // Clear the list of saved filenames
}

void displayMenuAVL() {
    cout << "Main Menu:\n";
    cout << "1. Display all items\n";
    cout << "2. Insert an item\n";
    cout << "3. Delete an item\n";
    cout << "4. Search for an item\n";
    cout << "5. Save to file\n";
    cout << "6. Load from file\n";
    cout << "7. Delete all saved files\n";
    cout << "0. Exit\n";
}

void AVLTreeProgram() {
    AVLTree tree = NULL;
    int choice, indexCounter = 1;
    PItem item;
    string fileName;

    do {
        displayMenuAVL();
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1:
                preOrder(tree);
                break;
            case 2:
                displayInsertMenuAVL();
                int insertChoice;
                cin >> insertChoice;
                switch (insertChoice) {
                    case 1:
                        incrementIndexes(tree);
                        item.index = 1;
                        cout << "Enter customer name: ";
                        cin >> item.customerName;
                        cout << "Enter customer surname: ";
                        cin >> item.customerSurname;
                        cout << "Enter item name: ";
                        cin.ignore();
                        cin.getline(item.itemName, 100);
                        cout << "Enter item value: ";
                        cin >> item.itemValue;
                        cout << "Enter contract date (day month year): ";
                        cin >> item.contractDate.day >> item.contractDate.month >> item.contractDate.year;
                        cout << "Enter maturity date (day month year): ";
                        cin >> item.maturityDate.day >> item.maturityDate.month >> item.maturityDate.year;
                        tree = insertNode(tree, item);
                        break;
                    case 2:
                        cout << "Enter customer name: ";
                        cin >> item.customerName;
                        cout << "Enter customer surname: ";
                        cin >> item.customerSurname;
                        cout << "Enter item name: ";
                        cin.ignore();
                        cin.getline(item.itemName, 100);
                        cout << "Enter item value: ";
                        cin >> item.itemValue;
                        cout << "Enter contract date (day month year): ";
                        cin >> item.contractDate.day >> item.contractDate.month >> item.contractDate.year;
                        cout << "Enter maturity date (day month year): ";
                        cin >> item.maturityDate.day >> item.maturityDate.month >> item.maturityDate.year;
                        item.index = indexCounter++;
                        tree = insertNode(tree, item);
                        break;
                    case 3:
                        cout << "Enter index to insert: ";
                        cin >> item.index;
                        incrementIndexesSpecific(tree, item.index);
                        cout << "Enter customer name: ";
                        cin >> item.customerName;
                        cout << "Enter customer surname: ";
                        cin >> item.customerSurname;
                        cout << "Enter item name: ";
                        cin.ignore();
                        cin.getline(item.itemName, 100);
                        cout << "Enter item value: ";
                        cin >> item.itemValue;
                        cout << "Enter contract date (day month year): ";
                        cin >> item.contractDate.day >> item.contractDate.month >> item.contractDate.year;
                        cout << "Enter maturity date (day month year): ";
                        cin >> item.maturityDate.day >> item.maturityDate.month >> item.maturityDate.year;
                        tree = insertNode(tree, item);
                        indexCounter++;
                        break;
                    default:
                        cout << "Invalid choice.\n";
                }
                break;
            case 3:
                displayDeleteMenuAVL();
                int deleteChoice;
                cin >> deleteChoice;
                switch (deleteChoice) {
                    case 1: {
                        int delIndex;
                        cout << "Enter index of the node to delete: ";
                        cin >> delIndex;
                        tree = deleteNode(tree, delIndex);
                        decrementIndexes(tree, delIndex);
                        indexCounter--;
                        break;
                    }
                    case 2: {
                        char delName[50], delSurname[50], delItemName[100];
                        cout << "Enter customer name: ";
                        cin >> delName;
                        cout << "Enter customer surname: ";
                        cin >> delSurname;
                        cout << "Enter item name: ";
                        cin.ignore();
                        cin.getline(delItemName, 100);
                        tree = deleteByValue(tree, delName, delSurname, delItemName);
                        indexCounter--; // Adjust indexCounter based on actual deletions
                        break;
                    }
                    default:
                        cout << "Invalid choice.\n";
                }
                break;
            case 4:
                displaySearchMenuAVL();
                int searchChoice;
                cin >> searchChoice;
                switch (searchChoice) {
                    case 1: {
                        int searchIndex;
                        cout << "Enter the index to search: ";
                        cin >> searchIndex;
                        Node* foundNode = searchByIndex(tree, searchIndex);
                        if (foundNode != NULL) {
                            cout << "Node found:\n";
                            cout << foundNode->data.index << " " << foundNode->data.customerName << " " << foundNode->data.customerSurname << " "
                                 << foundNode->data.itemName << " " << foundNode->data.itemValue << " "
                                 << foundNode->data.contractDate.day << "/" << foundNode->data.contractDate.month << "/" << foundNode->data.contractDate.year << " "
                                 << foundNode->data.maturityDate.day << "/" << foundNode->data.maturityDate.month << "/" << foundNode->data.maturityDate.year << endl;
                        } else {
                            cout << "Node not found.\n";
                        }
                        break;
                    }
                    case 2: {
                        char searchName[50], searchSurname[50], searchItemName[100];
                        cout << "Enter customer name: ";
                        cin >> searchName;
                        cout << "Enter customer surname: ";
                        cin >> searchSurname;
                        cout << "Enter item name: ";
                        cin.ignore();
                        cin.getline(searchItemName, 100);
                        cout << "Matching nodes:\n";
                        searchByValue(tree, searchName, searchSurname, searchItemName);
                        break;
                    }
                    default:
                        cout << "Invalid choice.\n";
                }
                break;
            case 5:
                displaySaveMenuAVL();
                int saveOption;
                cout << "Enter save option: ";
                cin >> saveOption;
                cin.ignore(); // Clear the input buffer
                cout << "Enter filename: ";
                cin >> fileName;
                if (saveOption == 1) {
                    fileName+=".txt";
                    saveToFile(fileName, false, tree); // Save as text file
                } else if (saveOption == 2) {
                    fileName+=".bin";
                    saveToFile(fileName, true, tree); // Save as binary file
                } else {
                    cout << "Invalid save option." << endl;
                }
                break;
            case 6:
    displayLoadMenuAVL();
    int loadOption;
    cout << "Enter load option: ";
    cin >> loadOption;
    cin.ignore(); // Clear the input buffer
    cout << "Enter filename: ";
    cin >> fileName;
    if (loadOption == 1) {
        fileName+=".txt";
        ifstream file(fileName);
        if (file.is_open()) {
            while (file >> item.index) {
                file >> item.customerName >> item.customerSurname >> item.itemName >> item.itemValue;
                char slash; // To ignore the slashes in the date format
                file >> item.contractDate.day >> slash >> item.contractDate.month >> slash >> item.contractDate.year;
                file >> item.maturityDate.day >> slash >> item.maturityDate.month >> slash >> item.maturityDate.year;
                tree = insertNode(tree, item); // Insert at the end
            }
            file.close();
            cout << "AVL tree loaded from .txt file successfully." << endl;
        } else {
            cout << "Error opening .txt file." << endl;
        }
    } else if (loadOption == 2) {
        fileName+=".bin";
        ifstream file(fileName, ios::binary);
        if (file.is_open()) {
            while (file.read((char*)&item, sizeof(PItem))) {
                tree = insertNode(tree, item); // Insert at the end
            }
            file.close();
            cout << "AVL tree loaded from .bin file successfully." << endl;
        } else {
            cout << "Error opening .bin file." << endl;
        }
    } else {
        cout << "Invalid load option." << endl;
    }
    break;
case 7:
                deleteAllSavedFilesAVL();
                break;
            case 0:
                break;
            default:
                cout << "Invalid choice.\n";
        }
    } while (choice != 0);

}